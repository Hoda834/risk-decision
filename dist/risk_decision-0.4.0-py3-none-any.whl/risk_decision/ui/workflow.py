import json
from datetime import date, timedelta
import streamlit as st
from risk_decision.wizard_core.lifecycle import add_action, complete_action, review_case, register_row
from risk_decision.wizard_core.intake import Extraction, QUESTIONS, extract_local, apply_confirmed
from risk_decision.wizard_core.storage import list_cases, read_draft


def render_register(paths):
    st.header('Risk register')
    rows = []
    for case in list_cases(paths):
        try:
            rows.append(register_row(read_draft(paths, case['case_id'])))
        except (ValueError, OSError) as exc:
            st.error(f"Cannot read {case['case_id']}: {exc}")
    mode = st.selectbox('Show', ['All', 'Overdue actions', 'Review due', 'Awaiting decision', 'Closed'])
    fields = {'Overdue actions': 'overdue_actions', 'Review due': 'review_due', 'Awaiting decision': 'awaiting_decision'}
    shown = [r for r in rows if mode == 'All' or (mode == 'Closed' and r['status'] == 'closed') or (mode in fields and r[fields[mode]])]
    st.dataframe(shown, use_container_width=True)
    st.download_button('Download register', json.dumps(rows, indent=2), 'risk-register.json', 'application/json')


def render_intake(payload, save):
    st.header('Describe the issue')
    if (payload.get('wizard') or {}).get('locked_at_end'):
        st.info('Create a new version in Assessment before changing this case.')
        return
    key = f"intake_{payload['case_id']}_{payload['version']}"
    source = st.text_area('Source text', value=(payload.get('intake') or {}).get('source', ''), key=key+'_source')
    model = st.text_input('Installed Ollama model (optional)', key=key+'_model')
    st.caption('Manual entry works without a model. AI suggestions require review; a matching quote does not prove the interpretation is correct.')
    if st.button('Extract with local model', key=key+'_extract'):
        try:
            result = extract_local(source, model)
            st.session_state[key] = {'source': source, 'result': result.model_dump(), 'model': model}
            for f in QUESTIONS:
                claim = getattr(result, f)
                st.session_state[key+'_'+f] = claim.text if claim else ''
        except ValueError as exc:
            st.error(str(exc))
    saved = st.session_state.get(key, {})
    if saved and saved['source'] != source:
        st.warning('Source changed. Extract again or clear the suggestions before saving.')
        if st.button('Clear suggestions', key=key+'_clear'):
            st.session_state.pop(key, None)
            for f in QUESTIONS:
                st.session_state.pop(key+'_'+f, None)
            st.rerun()
        return
    result = Extraction.model_validate(saved.get('result', {}))
    edits = {}
    for field, question in QUESTIONS.items():
        claim = getattr(result, field)
        if claim:
            st.caption('Source quote: '+claim.quote)
        else:
            st.caption(question)
        edits[field] = st.text_area(field.capitalize(), key=key+'_'+field)
    actor = st.text_input('Reviewed by', key=key+'_actor')
    confirm = st.checkbox('I have checked these statements against the source', key=key+'_confirmed')
    if st.button('Apply reviewed statements', disabled=not confirm, key=key+'_apply'):
        try:
            updated = apply_confirmed(payload, source, result, edits, actor)
            updated['intake']['model'] = saved.get('model', 'manual')
            payload.clear()
            payload.update(updated)
            for widget in list(st.session_state):
                if widget.startswith(f"q_{payload['case_id']}_{payload['version']}_"):
                    del st.session_state[widget]
            save(payload, 'intake_confirmed')
            st.success('Statements saved. Complete the remaining assessment fields in Assessment.')
        except ValueError as exc:
            st.error(str(exc))


def render_actions(payload, save):
    st.header('Actions and review')
    key = f"life_{payload['case_id']}_{payload['version']}"
    life = payload.get('lifecycle') or {}
    if life.get('status') == 'closed':
        st.success('Case closed. Create a new assessment version to reopen it.')
        st.json(life.get('reviews', []))
        return
    with st.form(key+'_add'):
        title = st.text_input('Action')
        owner = st.text_input('Action owner')
        due = st.date_input('Due date', value=date.today()+timedelta(days=7))
        submit = st.form_submit_button('Add action')
        if submit:
            try:
                add_action(payload, title, owner, due)
                save(payload, 'action_added')
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
    for action in (payload.get('lifecycle') or {}).get('actions', []):
        with st.expander(f"{action['title']} | {action['owner']} | {action['due']} | {action['status']}"):
            if action['status'] == 'completed':
                st.write(action['evidence'])
                continue
            evidence = st.text_area('Completion evidence', key=action['id']+'_evidence')
            actor = st.text_input('Recorded by', key=action['id']+'_actor')
            if st.button('Mark completed', key=action['id']+'_complete'):
                try:
                    complete_action(payload, action['id'], evidence, actor)
                    save(payload, 'action_completed')
                    st.rerun()
                except ValueError as exc:
                    st.error(str(exc))
    st.caption('Completion does not lower the risk score. Reassess in a new version before closing a case with completed actions.')
    with st.form(key+'_review'):
        actor = st.text_input('Reviewer')
        evidence = st.text_area('Observed result and supporting evidence')
        outcome = st.selectbox('Observed outcome', ['unknown', 'occurred', 'not_observed'])
        close = st.checkbox('Close this case after review')
        due = st.date_input('Next review if kept open', value=date.today()+timedelta(days=30))
        if st.form_submit_button('Record review'):
            try:
                review_case(payload, actor, evidence, outcome, close, due)
                save(payload, 'case_closed' if close else 'case_reviewed')
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
    st.json((payload.get('lifecycle') or {}).get('reviews', []))
