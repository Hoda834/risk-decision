"""Case actions and reviews. No action changes an assessment score."""
from copy import deepcopy
from datetime import date, datetime, timezone
from uuid import uuid4


def now():
    return datetime.now(timezone.utc).isoformat()


def state(payload):
    return payload.setdefault('lifecycle', {'status': 'open', 'actions': [], 'reviews': []})


def required(value, label):
    if not str(value).strip():
        raise ValueError(f'{label} is required.')
    return str(value).strip()


def add_action(payload, title, owner, due):
    life = state(payload)
    if life.get('status') == 'closed':
        raise ValueError('Reopen the case before adding actions.')
    action = dict(id=uuid4().hex[:12], title=required(title, 'Action'),
                  owner=required(owner, 'Owner'), due=date.fromisoformat(str(due)).isoformat(),
                  status='open', evidence='', created_at=now())
    life.setdefault('actions', []).append(action)
    return action


def complete_action(payload, action_id, evidence, actor):
    life = state(payload)
    if life.get('status') == 'closed':
        raise ValueError('The case is closed.')
    evidence, actor = required(evidence, 'Completion evidence'), required(actor, 'Recorded by')
    action = next((a for a in life.get('actions', []) if a['id'] == action_id), None)
    if action is None:
        raise ValueError('Unknown action.')
    if action['status'] == 'completed':
        raise ValueError('Action already completed.')
    action.update(status='completed', evidence=evidence, completed_by=actor, completed_at=now())


def review_case(payload, actor, evidence, outcome, close=False, next_review=None):
    life = state(payload)
    if life.get('status') == 'closed':
        raise ValueError('Reopen the case before reviewing it.')
    actor, evidence = required(actor, 'Reviewer'), required(evidence, 'Review evidence')
    if outcome not in ('occurred', 'not_observed', 'unknown'):
        raise ValueError('Invalid observed outcome.')
    snapshot, decision = payload.get('evaluation_snapshot') or {}, payload.get('decision') or {}
    if not snapshot or not decision.get('decided_at'):
        raise ValueError('Record an assessment and a human decision before review.')
    if close:
        if any(a['status'] != 'completed' for a in life.get('actions', [])):
            raise ValueError('Complete outstanding actions before closure.')
        if outcome == 'unknown':
            raise ValueError('An unknown outcome requires further review.')
        latest_completion = max((a.get('completed_at', '') for a in life.get('actions', [])), default='')
        if latest_completion and snapshot.get('created_at', '') <= latest_completion:
            raise ValueError('Create a new assessment version after the completed actions before closure.')
    elif next_review is None or date.fromisoformat(str(next_review)) <= date.today():
        raise ValueError('An open case needs a future review date.')
    record = dict(at=now(), reviewer=actor, evidence=evidence, outcome=outcome,
                  version=payload['version'], category=snapshot.get('risk_category'),
                  closed=close, next_review=None if close else str(next_review))
    life.setdefault('reviews', []).append(record)
    life.update(status='closed' if close else 'open', next_review=record['next_review'])
    return record


def revise(payload):
    result = deepcopy(payload)
    result['version'] += 1
    result['wizard'] = {'state': 'anchor', 'locked_at_end': False}
    for name in ('evaluation_snapshot', 'decision', 'feedback'):
        result[name] = None
    state(result)['status'] = 'open'
    return result


def register_row(payload, today=None):
    today = today or date.today()
    life, decision = payload.get('lifecycle') or {}, payload.get('decision') or {}
    closed = life.get('status') == 'closed'
    due = life.get('next_review') or decision.get('review_date')
    overdue = sum(a['status'] != 'completed' and date.fromisoformat(a['due']) < today
                  for a in life.get('actions', []))
    return dict(case_id=payload['case_id'], name=payload.get('anchor', {}).get('name', ''),
                owner=payload.get('anchor', {}).get('owner', ''), version=payload['version'],
                category=(payload.get('evaluation_snapshot') or {}).get('risk_category', 'unassessed'),
                status='closed' if closed else 'open', overdue_actions=overdue,
                awaiting_decision=bool(payload.get('evaluation_snapshot')) and not bool(decision.get('decided_at')),
                review_due=bool(not closed and due and date.fromisoformat(due) <= today),
                review_date=due or '')
